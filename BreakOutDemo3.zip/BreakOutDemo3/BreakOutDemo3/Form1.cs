﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BreakOutDemo3
{
    public partial class Form1 : Form
    {
        private Ball ball;
        private Paddle paddle;
        private Brick brick;
        private PictureBox[,] pictureBoxes;

        public Form1()
        {
            InitializeComponent();
            ball = new Ball(picBall);
            paddle = new Paddle(picPaddle);
            brick = new Brick(pictureBoxes);
            

        }
        

        private void timer1_Tick(object sender, EventArgs e)
        {
            ball.MoveBall();
            
            
           


        }

        private void picPaddle_Click(object sender, EventArgs e)
        {

        }

        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
            paddle.MovePaddle();
        }
    }
}
