﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BreakOutDemo3
{
    public class Manager
    {
        private int score;
    

    public Manager()
    {

    }

    public void ShowScore()
    {

    }
}
