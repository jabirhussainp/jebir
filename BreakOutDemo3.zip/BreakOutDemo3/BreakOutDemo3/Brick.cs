﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BreakOutDemo3
{
    public class Brick
    {
        private PictureBox[,] pictureBoxes;
        private const int row = 8;
        private const int col = 8;

        public Brick(PictureBox[,] pictureBoxes)
        {
            this.pictureBoxes = pictureBoxes;
        }

        public void SetBlocks()
        {
            int blockHeight = 25;
            int blockWidth = 100;

            pictureBoxes = new PictureBox[row, col];

            for (int x = 0; x < row; x++)
            {
                for (int y = 0; y < col; y++)
                {
                    pictureBoxes[x, y] = new PictureBox();

                    pictureBoxes[x, y].Width = blockWidth;
                    pictureBoxes[x, y].Height = blockHeight;
                    pictureBoxes[x, y].Top = blockHeight * x;
                    pictureBoxes[x, y].Left = blockWidth * y;
                    pictureBoxes[x, y].BackColor = Color.Beige;
                    pictureBoxes[x, y].BorderStyle = BorderStyle.Fixed3D;

                    
                }
            }
        }
    }
}
